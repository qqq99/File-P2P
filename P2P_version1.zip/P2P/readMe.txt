## the source code is in p2p directory, cd to it and use this command to generate jar file
mvn package
# move jar with dependences to runnable directory and rename it to bitbox.jar

## I already generate a jar file in the runnable directory, go into it

## run the jar using this command
java -cp bitbox.jar unimelb.bitbox.Peer

# in order to make topology, we should run the jar 3 time with different configuration, before ecah time we run the jar, we should change configuration to 3 different content as below

path = share1
port = 9000
advertisedName = localhost
peers = localhost:9001
maximumIncommingConnections = 10
blockSize = 1048576
syncInterval = 60

path = share2
port = 9001
advertisedName = localhost
peers = localhost:9000
maximumIncommingConnections = 10
blockSize = 1048576
syncInterval = 60

path = share3
port = 9002
advertisedName = localhost
peers = localhost:9001
maximumIncommingConnections = 10
blockSize = 1048576
syncInterval = 60

Then you change the content in the directory share1, share2 and share3, they will synchroize

