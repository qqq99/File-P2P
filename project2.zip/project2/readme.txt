## compile and package
1.cd into bitbox dir, use following command to compile and package
mvn package

2.cd into bitbox/target, find the jar with dependences and copy it to runable dir, rename it as "bitbox.jar"

## run and show
This program has 3 kinds of usage, I write them in 3 different file which named tcp.txt, udp.txt and client.txt. Read these file to get a good understanding of how to run the program
